/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import {
  siteConfig,
  youtubeServices,
  instagramServices,
  youtubeCategories,
  instagramCategories,
  ServiceItem,
} from './config';
import { AnnouncementBanner } from './components/AnnouncementBanner';
import { Header } from './components/Header';
import { NavigationDrawer, AppScreen } from './components/NavigationDrawer';
import { PlatformFilter } from './components/PlatformFilter';
import { ServiceCard } from './components/ServiceCard';
import { OrderModal } from './components/OrderModal';
import { PaymentScreen } from './components/screens/PaymentScreen';
import { HowItWorksScreen } from './components/screens/HowItWorksScreen';
import { OrdersScreen } from './components/screens/OrdersScreen';
import { SettingsScreen } from './components/screens/SettingsScreen';
import { AboutScreen } from './components/screens/AboutScreen';
import { WhatsAppButton } from './components/WhatsAppButton';
import { Footer } from './components/Footer';
import { getLocalOrders, OrderRecord } from './utils/storage';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('home');
  const [selectedPlatform, setSelectedPlatform] = useState<'youtube' | 'instagram'>('youtube');
  const [selectedCategory, setSelectedCategory] = useState<string>(youtubeCategories[0]);
  const [activeOrderService, setActiveOrderService] = useState<ServiceItem | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isNavMenuOpen, setIsNavMenuOpen] = useState(false);
  const [localOrderCount, setLocalOrderCount] = useState<number>(0);
  const [paymentAmount, setPaymentAmount] = useState<number | undefined>(undefined);

  // Sync local order count
  useEffect(() => {
    const orders = getLocalOrders();
    setLocalOrderCount(orders.length);
  }, []);

  const refreshOrderCount = () => {
    const orders = getLocalOrders();
    setLocalOrderCount(orders.length);
  };

  // When platform switches, reset default category
  const handleSelectPlatform = (platform: 'youtube' | 'instagram') => {
    setCurrentScreen('home');
    setSelectedPlatform(platform);
    if (platform === 'youtube') {
      setSelectedCategory(youtubeCategories[0]);
    } else {
      setSelectedCategory(instagramCategories[0]);
    }
  };

  // Reorder displayed services so that the selected category is at the top
  const displayedServices = useMemo(() => {
    const baseList = selectedPlatform === 'youtube' ? youtubeServices : instagramServices;
    const matching = baseList.filter((s) => s.category.toLowerCase() === selectedCategory.toLowerCase());
    const rest = baseList.filter((s) => s.category.toLowerCase() !== selectedCategory.toLowerCase());
    return [...matching, ...rest];
  }, [selectedPlatform, selectedCategory]);

  const handleOrderClick = (service: ServiceItem) => {
    setActiveOrderService(service);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
  };

  const handleOrderSaved = (saved: OrderRecord) => {
    refreshOrderCount();
    setPaymentAmount(saved.amount);
  };

  const handleNavigate = (screen: AppScreen, targetPlatform?: 'youtube' | 'instagram') => {
    if (targetPlatform) {
      setSelectedPlatform(targetPlatform);
      if (targetPlatform === 'youtube') {
        setSelectedCategory(youtubeCategories[0]);
      } else {
        setSelectedCategory(instagramCategories[0]);
      }
    }
    setCurrentScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenPaymentScreenWithAmount = (amount: number) => {
    setPaymentAmount(amount);
    setCurrentScreen('payment');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0b0c10] text-zinc-100 flex flex-col font-sans selection:bg-purple-600/40 selection:text-white">
      {/* PINNED STICKY TOP CONTAINER (Banner + Header + Filters remain fixed on screen while scrolling) */}
      <div className="sticky top-0 z-40 bg-[#0b0c10]/98 backdrop-blur-md border-b border-zinc-800 shadow-xl shadow-black/50">
        {/* 1. Top Announcement Banner */}
        <AnnouncementBanner />

        {/* 2. Header */}
        <Header
          onGoHome={() => handleNavigate('home')}
          onOpenMenu={() => setIsNavMenuOpen(true)}
          orderCount={localOrderCount}
        />

        {/* Pinned Platform + Category Filter (pinned on homepage) */}
        {currentScreen === 'home' && (
          <div className="px-2 pt-1 pb-1 border-t border-zinc-900/60 bg-[#0b0c10]/95">
            <PlatformFilter
              selectedPlatform={selectedPlatform}
              onSelectPlatform={handleSelectPlatform}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />
          </div>
        )}
      </div>

      {/* Slide-out Hamburger Navigation Menu */}
      <NavigationDrawer
        isOpen={isNavMenuOpen}
        onClose={() => setIsNavMenuOpen(false)}
        activeScreen={currentScreen}
        onNavigate={handleNavigate}
        orderCount={localOrderCount}
      />

      {/* MULTI-SCREEN CLIENT-SIDE VIEW SWITCHING */}
      {currentScreen === 'home' && (
        <div className="flex-1 flex flex-col">
          {/* Main Heading (Notice removed from here and moved onto Demo Plan card) */}
          <section id="hero" className="relative pt-6 pb-2 px-4 text-center overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-48 bg-gradient-to-b from-purple-700/15 via-purple-900/5 to-transparent blur-3xl pointer-events-none" />

            <div className="max-w-3xl mx-auto relative z-10">
              <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white leading-tight">
                Elevate Your Reach with{' '}
                <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-300 bg-clip-text text-transparent">
                  {siteConfig.name}
                </span>
              </h1>
            </div>
          </section>

          {/* Service / Package Cards (These scroll smoothly underneath the pinned top header & filters) */}
          <main className="max-w-6xl mx-auto px-4 py-4 w-full flex-1">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2 capitalize">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-300 to-pink-300">
                    {selectedCategory}
                  </span>{' '}
                  {selectedPlatform === 'youtube' ? 'YouTube' : 'Instagram'} Packages
                </h2>
                <p className="text-xs sm:text-sm text-zinc-400 mt-0.5">
                  Select any package below to configure your order with manual verification.
                </p>
              </div>

              <div className="text-xs font-mono text-zinc-400 bg-zinc-900 px-3 py-1.5 rounded-lg border border-zinc-800">
                {displayedServices.length} Packages Available
              </div>
            </div>

            {/* Service Cards Grid */}
            <div
              id="services-grid"
              key={`${selectedPlatform}-${selectedCategory}`}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5 sm:gap-4.5 animate-in fade-in slide-in-from-bottom-2 duration-300"
            >
              {displayedServices.map((service, idx) => {
                const isFirstOfCategory =
                  idx === 0 || displayedServices[idx - 1].category !== service.category;
                const categoryAnchorId = isFirstOfCategory
                  ? `category-${service.category.toLowerCase().replace(/\s+/g, '-')}`
                  : undefined;

                return (
                  <div key={service.id} id={categoryAnchorId} className="scroll-mt-36">
                    <ServiceCard service={service} onOrder={handleOrderClick} />
                  </div>
                );
              })}
            </div>
          </main>
        </div>
      )}

      {/* SEPARATE SCREEN: PAYMENT / QR */}
      {currentScreen === 'payment' && (
        <PaymentScreen
          onBack={() => handleNavigate('home')}
          selectedAmount={paymentAmount}
        />
      )}

      {/* SEPARATE SCREEN: HOW IT WORKS */}
      {currentScreen === 'how-it-works' && (
        <HowItWorksScreen onBack={() => handleNavigate('home')} />
      )}

      {/* SEPARATE SCREEN: MY ORDERS */}
      {currentScreen === 'orders' && (
        <OrdersScreen
          onBack={() => handleNavigate('home')}
          onOrdersUpdated={refreshOrderCount}
        />
      )}

      {/* SEPARATE SCREEN: SETTINGS */}
      {currentScreen === 'settings' && (
        <SettingsScreen
          onBack={() => handleNavigate('home')}
          onDataChanged={refreshOrderCount}
        />
      )}

      {/* SEPARATE SCREEN: ABOUT CREATOR SUPPORTER */}
      {currentScreen === 'about' && (
        <AboutScreen onBack={() => handleNavigate('home')} />
      )}

      {/* Clean Footer */}
      <Footer />

      {/* Floating WhatsApp Button */}
      <WhatsAppButton />

      {/* Order / Checkout Modal */}
      <OrderModal
        isOpen={isModalOpen}
        service={activeOrderService}
        onClose={handleCloseModal}
        onOrderSaved={handleOrderSaved}
        onOpenPaymentScreen={handleOpenPaymentScreenWithAmount}
      />
    </div>
  );
}
