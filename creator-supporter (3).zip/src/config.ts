/**
 * =======================================================================
 * CREATOR SUPPORTER - CONFIGURATION FILE
 * =======================================================================
 * Everything on this website is controlled from this single file.
 * You can easily edit prices, service names, UPI details, WhatsApp numbers,
 * email, announcements, and delivery notices below.
 * No database or backend required.
 */

export interface ServiceItem {
  id: string;
  category: string; // 'Demo' | 'Creator Pro' | 'Half Monetize' | 'VIP' for YT, or 'Demo' | 'Followers' | 'Likes' | 'Reels' | 'Post Views' for IG
  name: string;
  platform: 'youtube' | 'instagram';
  quantityDisplay: string; // e.g. '111', '500', '1K', '3K Hours', '4K Hours', '120', '15K'
  unitLabel: string;       // e.g. 'Subscribers', 'Followers', 'Likes', 'Reel Views'
  description: string;
  package: string;
  price: number; // in INR (₹)
  popular?: boolean;
  features: string[];
}

export interface SiteConfig {
  name: string;
  tagline: string;
  announcement: {
    mainText: string;
  };
  email: string;
  whatsapp: {
    display: string; // Formatted number displayed in text
    number: string;  // Digits only with country code for WhatsApp link
  };
  payment: {
    upiId: string;
    payeeName: string;
    qrImagePath: string;
    instructionsHindi: string;
    verificationNoteHindi: string;
  };
  notice: string;
  deliveryNotice: {
    shortNotice: string;
    description: string;
    whatsappHelp: string;
  };
}

export const siteConfig: SiteConfig = {
  // Website Branding
  name: 'Creator Supporter',
  tagline: 'Simple creator promotion & social-media support services.',

  // Top Announcement Banner
  announcement: {
    mainText: 'THANK YOU FOR WATCHING',
  },

  // Contact Information
  email: 'hindustan803200@gmail.com',
  whatsapp: {
    display: '+91 92969 65248',
    number: '919296965248', // 9296965248 with India country code 91
  },

  // Payment Configuration
  payment: {
    upiId: 'youtubesupporter@axl',
    payeeName: 'Creator Supporter',
    qrImagePath: '/phonepe-qr.png',
    instructionsHindi: 'Payment करने के बाद WhatsApp पर अपना नाम, Channel/Profile का link भेजें.',
    verificationNoteHindi: 'Payment manually verify किया जाएगा.',
  },

  // Notice directly under main heading
  notice: 'Demo subscriber/follower packages are not guaranteed. Other promotional services are subject to campaign availability and platform conditions.',

  // Delivery notice on every service card
  deliveryNotice: {
    shortNotice: 'Service processing time: 10 minutes to 1 hour.',
    description: 'Most orders are processed within 10 minutes to 1 hour. Processing can vary depending on campaign/platform conditions.',
    whatsappHelp: 'If your order is not processed within the expected time, contact us on WhatsApp.',
  },
};

/**
 * YouTube Categories in exact required order:
 * 1. Demo (under ₹100, e.g. ₹39)
 * 2. Creator Pro (₹199, ₹299)
 * 3. Half Monetize (₹499)
 * 4. VIP (₹999)
 */
export const youtubeCategories = ['Demo', 'Creator Pro', 'Half Monetize', 'VIP', 'Signature'] as const;

export const youtubeServices: ServiceItem[] = [
  // 1. Demo Plan (Under ₹100: ₹39)
  {
    id: 'yt-demo-111',
    category: 'Demo',
    name: 'Demo Plan',
    platform: 'youtube',
    quantityDisplay: '111',
    unitLabel: 'Subscribers',
    description: 'Sample starter package under ₹100 for creators to evaluate our promotion speed and natural delivery pacing.',
    package: '111 Channel Subscribers',
    price: 39,
    popular: false,
    features: [
      '111 Channel Subscribers',
      'Channel link only (no password required)',
      'Natural gradual distribution',
      'Safe profile pacing',
    ],
  },

  // 2. Creator Pro
  {
    id: 'yt-pro-500',
    category: 'Creator Pro',
    name: 'Creator Pro Growth',
    platform: 'youtube',
    quantityDisplay: '500',
    unitLabel: 'Subscribers',
    description: 'Expanded subscriber boost for active YouTube creators seeking consistent audience momentum.',
    package: '500 Channel Subscribers',
    price: 199,
    popular: false,
    features: [
      '500 Channel Subscribers',
      'High retention distribution pool',
      'Steady delivery pacing',
      'Safe for channels of any age',
    ],
  },
  {
    id: 'yt-pro-1k',
    category: 'Creator Pro',
    name: 'Creator Pro Milestone',
    platform: 'youtube',
    quantityDisplay: '1K',
    unitLabel: 'Subscribers',
    description: 'Significant 1,000 subscriber benchmark boost to build channel authority and presence.',
    package: '1,000 Channel Subscribers',
    price: 299,
    popular: false,
    features: [
      '1,000 Channel Subscribers',
      'Milestone distribution campaign',
      'Consistent drip-feed pacing',
      'Direct order tracking on WhatsApp',
    ],
  },

  // 3. Half Monetize (₹699)
  {
    id: 'yt-half-monetize-699',
    category: 'Half Monetize',
    name: 'Half Monetize Plan',
    platform: 'youtube',
    quantityDisplay: '3K Hours',
    unitLabel: '500 Subs + 3K Hours',
    description: 'Includes 500 subscribers, 3,000 watch time hours, necessary video views required to complete 3,000 hours watch time, and 500 to 2,000 likes.',
    package: 'Half Monetize (500 Subs + 3,000 Watch Hours)',
    price: 699,
    popular: true,
    features: [
      '500 Channel Subscribers',
      '3,000 Watch Time Hours',
      'Views required to complete 3,000 watch hours',
      '500 to 2,000 Video Likes',
      'Multi-video link campaign distribution',
      'Dedicated support via WhatsApp',
    ],
  },

  // 4. VIP Plan (₹999)
  {
    id: 'yt-vip-monetize-999',
    category: 'VIP',
    name: 'VIP Plan',
    platform: 'youtube',
    quantityDisplay: '4K Hours',
    unitLabel: '1K Subs + 4K Hours',
    description: 'Includes 1,000 subscribers, 4,000 watch time hours, necessary video views required to complete 4,000 hours watch time, and 1,000 to 3,000 likes.',
    package: 'VIP Plan (1,000 Subs + 4,000 Watch Hours)',
    price: 999,
    popular: true,
    features: [
      '1,000 Channel Subscribers',
      '4,000 Watch Time Hours',
      'Views required to complete 4,000 watch hours',
      '1,000 to 3,000 Video Likes',
      'Full monetization milestone campaign',
      'Priority queue & dedicated WhatsApp manager',
    ],
  },

  // 5. Signature Plan (₹1,499)
  {
    id: 'yt-signature-10k',
    category: 'Signature',
    name: 'Signature Plan',
    platform: 'youtube',
    quantityDisplay: '10K',
    unitLabel: 'Subscribers',
    description: 'High-volume 10,000 subscriber milestone campaign for creators aiming for top-tier audience expansion and brand credibility.',
    package: 'Signature Plan (10,000 Subscribers)',
    price: 1499,
    popular: true,
    features: [
      '10,000 Channel Subscribers',
      'High retention distribution pool',
      'Staged organic multi-day delivery',
      'Safe for channels of any age',
      'Priority queue & dedicated WhatsApp manager',
    ],
  },
];

/**
 * Instagram Categories in exact required order:
 * 1. Demo (Under ₹100, e.g. ₹45)
 * 2. Followers
 * 3. Likes
 * 4. Reels
 * 5. Post Views
 */
export const instagramCategories = ['Demo', 'Followers', 'Likes', 'Reels', 'Post Views'] as const;

export const instagramServices: ServiceItem[] = [
  // 1. Demo Plan (Under ₹100: ₹45)
  {
    id: 'ig-demo-120',
    category: 'Demo',
    name: 'Demo Plan',
    platform: 'instagram',
    quantityDisplay: '120',
    unitLabel: 'Followers',
    description: 'Sample starter test plan under ₹100 to evaluate profile delivery quality and speed.',
    package: 'Demo Plan (120 Followers)',
    price: 45,
    popular: false,
    features: [
      '120 Profile Followers',
      'Profile link / handle only',
      'No password required',
      'Fast initial test delivery',
    ],
  },
  {
    id: 'ig-demo-likes-500',
    category: 'Demo',
    name: 'Demo Plan Likes',
    platform: 'instagram',
    quantityDisplay: '500',
    unitLabel: 'Post Likes',
    description: 'Sample post interaction test plan under ₹100 for any photo, reel, or carousel.',
    package: 'Demo Plan (500 Post Likes)',
    price: 45,
    popular: false,
    features: [
      '500 Post & Reel Likes',
      'Works on photos, reels, & carousels',
      'No password required',
      'Safe interaction pacing',
    ],
  },

  // 2. Followers
  {
    id: 'ig-fol-500',
    category: 'Followers',
    name: 'Instagram Followers',
    platform: 'instagram',
    quantityDisplay: '500',
    unitLabel: 'Followers',
    description: 'Quality profile booster to strengthen social proof and account appearance.',
    package: '500 Profile Followers',
    price: 199,
    popular: true,
    features: [
      '500 Profile Followers',
      'Organic speed distribution',
      'Zero password requirement',
      'WhatsApp order status updates',
    ],
  },
  {
    id: 'ig-fol-1k',
    category: 'Followers',
    name: 'Instagram Followers',
    platform: 'instagram',
    quantityDisplay: '1K',
    unitLabel: 'Followers',
    description: 'Milestone 1,000 profile follower package for active digital creators.',
    package: '1,000 Profile Followers',
    price: 349,
    popular: false,
    features: [
      '1,000 Profile Followers',
      'High retention distribution',
      'Steady delivery pacing',
      'Safe for all accounts',
    ],
  },
  {
    id: 'ig-fol-15k',
    category: 'Followers',
    name: 'Instagram Followers',
    platform: 'instagram',
    quantityDisplay: '15K',
    unitLabel: 'Followers',
    description: 'Large-scale follower campaign for established brand or creator accounts.',
    package: '15,000 Profile Followers',
    price: 2499,
    popular: false,
    features: [
      '15,000 Profile Followers',
      'Staged multi-day delivery',
      'Priority queue processing',
      'Personal campaign handling',
    ],
  },

  // 3. Likes
  {
    id: 'ig-likes-2k',
    category: 'Likes',
    name: 'Instagram Likes',
    platform: 'instagram',
    quantityDisplay: '2K',
    unitLabel: 'Post Likes',
    description: 'Strong interaction boost helping post reach and Explore page visibility.',
    package: '2,000 Post & Reel Likes',
    price: 199,
    popular: true,
    features: [
      '2,000 Post & Reel Likes',
      'Split across up to 2 posts',
      'Safe natural pacing',
      'WhatsApp notification',
    ],
  },
  {
    id: 'ig-likes-5k',
    category: 'Likes',
    name: 'Instagram Likes',
    platform: 'instagram',
    quantityDisplay: '5K',
    unitLabel: 'Post Likes',
    description: 'High-volume post like distribution for viral trending campaigns.',
    package: '5,000 Post & Reel Likes',
    price: 349,
    popular: false,
    features: [
      '5,000 Post & Reel Likes',
      'Split across up to 3 posts',
      'Fast delivery execution',
      'Direct order support',
    ],
  },
  {
    id: 'ig-likes-25k',
    category: 'Likes',
    name: 'Instagram Likes',
    platform: 'instagram',
    quantityDisplay: '25K',
    unitLabel: 'Post Likes',
    description: 'Heavy engagement push for major campaigns and product launches.',
    package: '25,000 Post & Reel Likes',
    price: 2499,
    popular: false,
    features: [
      '25,000 Post & Reel Likes',
      'Split across up to 10 posts',
      'Priority VIP queue',
      'Dedicated handling',
    ],
  },

  // 4. Reels
  {
    id: 'ig-reels-5k',
    category: 'Reels',
    name: 'Instagram Reel Views',
    platform: 'instagram',
    quantityDisplay: '5K',
    unitLabel: 'Reel Views',
    description: 'Give new reels fast watch traction to help reach larger explore audiences.',
    package: '5,000 High Speed Reel Views',
    price: 149,
    popular: false,
    features: [
      '5,000 Reel Views',
      'Fast start on new reels',
      'Public reel link only',
      'Natural view pacing',
    ],
  },
  {
    id: 'ig-reels-15k',
    category: 'Reels',
    name: 'Instagram Reel Views',
    platform: 'instagram',
    quantityDisplay: '15K',
    unitLabel: 'Reel Views',
    description: 'Viral momentum campaign for high-potential creator reel videos.',
    package: '15,000 High Speed Reel Views',
    price: 299,
    popular: true,
    features: [
      '15,000 Reel Views',
      'Accelerated watch distribution',
      'Smooth continuous delivery',
      'WhatsApp confirmation',
    ],
  },
  {
    id: 'ig-reels-50k',
    category: 'Reels',
    name: 'Instagram Reel Views',
    platform: 'instagram',
    quantityDisplay: '50000',
    unitLabel: 'Reel Views',
    description: 'Massive scale reel reach campaign for standout creative videos.',
    package: '50,000 High Speed Reel Views',
    price: 699,
    popular: false,
    features: [
      '50,000 Reel Views',
      'Split between 2 reels allowed',
      'Priority processing queue',
      'WhatsApp assistance',
    ],
  },

  // 5. Post Views
  {
    id: 'ig-views-3k',
    category: 'Post Views',
    name: 'Instagram Post Views',
    platform: 'instagram',
    quantityDisplay: '3K',
    unitLabel: 'Post Views',
    description: 'Video and carousel impressions boost for feed posts.',
    package: '3,000 Post & Video Views',
    price: 129,
    popular: false,
    features: [
      '3,000 Post & Video Views',
      'Supports video carousels & clips',
      'Clean organic distribution',
      'Public profile required',
    ],
  },
  {
    id: 'ig-views-10k',
    category: 'Post Views',
    name: 'Instagram Post Views',
    platform: 'instagram',
    quantityDisplay: '10K',
    unitLabel: 'Post Views',
    description: 'Substantial impression coverage across your posts and video feeds.',
    package: '10,000 Post & Video Views',
    price: 249,
    popular: false,
    features: [
      '10,000 Post & Video Views',
      'Substantial impression growth',
      'Fast execution after payment',
      'WhatsApp order confirmation',
    ],
  },
];
