import React, { useState } from 'react';
import { siteConfig } from '../../config';
import { buildUpiDeepLink } from '../../utils/links';
import {
  ArrowLeft,
  Copy,
  Check,
  Smartphone,
  AlertCircle,
  QrCode,
  ShieldCheck,
} from 'lucide-react';

interface PaymentScreenProps {
  onBack: () => void;
  selectedAmount?: number;
}

export const PaymentScreen: React.FC<PaymentScreenProps> = ({
  onBack,
  selectedAmount,
}) => {
  const [copied, setCopied] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [showUpiFallbackNotice, setShowUpiFallbackNotice] = useState(false);

  const { upiId, qrImagePath, instructionsHindi, verificationNoteHindi } =
    siteConfig.payment;

  const handleCopyUpiId = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(upiId);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = upiId;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handlePayWithUpiApp = () => {
    const deepLink = buildUpiDeepLink(selectedAmount);
    window.location.href = deepLink;

    setTimeout(() => {
      setShowUpiFallbackNotice(true);
    }, 1800);
  };

  return (
    <div className="w-full flex-1 max-w-xl mx-auto px-4 py-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>← Back</span>
      </button>

      {/* Screen Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/70 border border-purple-800/40 text-purple-300 text-xs font-bold uppercase tracking-widest mb-2.5">
          <ShieldCheck className="w-3.5 h-3.5 text-purple-400" />
          <span>Direct UPI Gateway</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight uppercase">
          PAYMENT
        </h1>
        <p className="text-zinc-400 text-sm sm:text-base mt-1">
          Scan & Pay Using UPI
        </p>

        {selectedAmount && selectedAmount > 0 && (
          <div className="mt-3 inline-flex items-center gap-2 px-3.5 py-1 rounded-xl bg-purple-950/80 border border-purple-600/50 text-purple-200 text-xs font-bold">
            <span>Amount: <strong className="text-white font-mono">₹{selectedAmount}</strong></span>
          </div>
        )}
      </div>

      {/* Main Payment Card */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center">
        {/* Payment Instructions */}
        <div className="w-full mb-6 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-center space-y-2">
          <p className="text-xs sm:text-sm font-semibold text-purple-200 leading-relaxed">
            "{instructionsHindi}"
          </p>
          <p className="text-xs font-bold text-amber-400">
            "{verificationNoteHindi}"
          </p>
        </div>

        {/* Large Centered Responsive QR Code */}
        <div className="w-full max-w-[280px] sm:max-w-[320px] bg-white p-4 rounded-2xl shadow-xl flex flex-col items-center justify-center">
          <div className="w-full aspect-square flex items-center justify-center overflow-hidden">
            {!imgError ? (
              <img
                src={qrImagePath}
                alt="PhonePe UPI Payment QR Code"
                onError={() => setImgError(true)}
                className="w-full h-full object-contain"
                loading="eager"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center text-center p-4 text-zinc-800">
                <QrCode className="w-12 h-12 text-zinc-500 mb-2" />
                <p className="text-xs font-bold">QR Image Missing</p>
                <code className="text-[10px] font-mono mt-1 text-zinc-600">
                  public/phonepe-qr.png
                </code>
              </div>
            )}
          </div>
          <p className="text-[11px] font-bold text-zinc-700 tracking-wider uppercase mt-2">
            Scan with any UPI App
          </p>
        </div>

        {/* UPI ID Box */}
        <div className="mt-6 w-full bg-zinc-950 rounded-2xl border border-zinc-800 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-center sm:text-left">
            <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-500 block">
              UPI ID
            </span>
            <span className="font-mono text-sm sm:text-base font-bold text-white select-all">
              {upiId}
            </span>
          </div>

          <button
            type="button"
            onClick={handleCopyUpiId}
            className={`w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white border border-zinc-700'
            }`}
            aria-label="Copy UPI ID"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-white" />
                <span>Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-zinc-400" />
                <span>Copy UPI ID</span>
              </>
            )}
          </button>
        </div>

        {/* Pay with UPI App Button */}
        <div className="mt-3.5 w-full">
          <button
            type="button"
            onClick={handlePayWithUpiApp}
            className="order-now-btn w-full flex items-center justify-center gap-2.5 py-3.5 px-6 rounded-2xl text-white font-extrabold text-sm sm:text-base shadow-xl shadow-purple-950/60 cursor-pointer"
          >
            <Smartphone className="w-5 h-5" />
            <span>
              Pay with UPI App
              {selectedAmount && selectedAmount > 0 ? ` (₹${selectedAmount})` : ''}
            </span>
          </button>

          {/* Deep link fallback notice */}
          {showUpiFallbackNotice && (
            <div className="mt-3 p-3 rounded-xl bg-amber-950/40 border border-amber-800/40 text-amber-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p>
                  UPI app could not be opened automatically. Please scan the QR code above or copy the UPI ID.
                </p>
                <button
                  onClick={() => setShowUpiFallbackNotice(false)}
                  className="mt-1 text-[11px] underline text-amber-200 hover:text-white cursor-pointer"
                >
                  Dismiss
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
