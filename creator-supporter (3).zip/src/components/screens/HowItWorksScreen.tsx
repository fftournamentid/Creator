import React from 'react';
import {
  ArrowLeft,
  Layers,
  Sparkles,
  Package,
  FileEdit,
  QrCode,
  MessageSquare,
  ShieldCheck,
} from 'lucide-react';

interface HowItWorksScreenProps {
  onBack: () => void;
}

const steps = [
  {
    step: '01',
    title: 'Select YouTube or Instagram',
    desc: 'Choose between YouTube or Instagram depending on which creator platform you want to promote.',
    icon: Layers,
  },
  {
    step: '02',
    title: 'Select a Service Category',
    desc: 'Pick your desired category: Demo, Creator Pro, Half Promotion, VIP, or Instagram options.',
    icon: Sparkles,
  },
  {
    step: '03',
    title: 'Select Your Package',
    desc: 'Choose your desired subscriber, view, follower, or like quantity with transparent upfront pricing.',
    icon: Package,
  },
  {
    step: '04',
    title: 'Enter Required Details',
    desc: 'Provide your WhatsApp number and target channel or profile link.',
    icon: FileEdit,
  },
  {
    step: '05',
    title: 'Complete Payment',
    desc: 'Scan the UPI QR code or tap "Pay with UPI App" using PhonePe, Google Pay, Paytm, or any UPI app.',
    icon: QrCode,
  },
  {
    step: '06',
    title: 'Direct Order Share on WhatsApp',
    desc: 'Tap "Share Order on WhatsApp" to send your complete order details directly to our official WhatsApp (+91 92969 65248).',
    icon: MessageSquare,
  },
  {
    step: '07',
    title: 'Payment is Manually Verified & Processed',
    desc: 'Payment is manually verified and campaign processing begins (typically within 10 minutes to 1 hour).',
    icon: ShieldCheck,
  },
];

export const HowItWorksScreen: React.FC<HowItWorksScreenProps> = ({ onBack }) => {
  return (
    <div className="w-full flex-1 max-w-5xl mx-auto px-4 py-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>← Back</span>
      </button>

      {/* Screen Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/70 border border-purple-800/40 text-purple-300 text-xs font-bold uppercase tracking-widest mb-3">
          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
          <span>Step-by-Step Workflow</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          How It Works
        </h1>
        <p className="text-zinc-400 text-xs sm:text-sm mt-2 max-w-lg mx-auto leading-relaxed">
          Follow these 7 simple steps to select packages, complete UPI payment, and receive manual order verification.
        </p>
      </div>

      {/* 7 Steps Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {steps.map((item, idx) => {
          const Icon = item.icon;
          const isLast = idx === steps.length - 1;
          return (
            <div
              key={item.step}
              className={`bg-zinc-900/80 border border-zinc-800 rounded-3xl p-5 relative flex flex-col justify-between hover:border-purple-500/40 transition-all ${
                isLast
                  ? 'sm:col-span-2 lg:col-span-2 bg-gradient-to-br from-zinc-900 via-purple-950/30 to-zinc-900'
                  : ''
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-xs font-black text-purple-300 bg-purple-950/90 px-2.5 py-1 rounded-lg border border-purple-800/40">
                    Step {item.step}
                  </span>
                  <div className="w-8 h-8 rounded-xl bg-purple-950/60 border border-purple-800/40 flex items-center justify-center text-purple-400">
                    <Icon className="w-4 h-4" />
                  </div>
                </div>

                <h3 className="text-base font-bold text-white mb-1.5">
                  {item.title}
                </h3>

                <p className="text-xs text-zinc-400 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
