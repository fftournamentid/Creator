import React, { useState, useEffect } from 'react';
import {
  getLocalSettings,
  saveLocalSettings,
  resetLocalSettings,
  clearLocalOrders,
  UserSettings,
} from '../../utils/storage';
import {
  ArrowLeft,
  Save,
  RotateCcw,
  Trash2,
  Shield,
  Smartphone,
  User,
} from 'lucide-react';

interface SettingsScreenProps {
  onBack: () => void;
  onDataChanged: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  onBack,
  onDataChanged,
}) => {
  const [whatsapp, setWhatsapp] = useState('');
  const [name, setName] = useState('');
  const [savedSuccessMsg, setSavedSuccessMsg] = useState('');

  useEffect(() => {
    const s = getLocalSettings();
    setWhatsapp(s.savedWhatsapp || '');
    setName(s.savedName || '');
  }, []);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserSettings = {
      savedWhatsapp: whatsapp.trim() || undefined,
      savedName: name.trim() || undefined,
    };
    saveLocalSettings(updated);
    setSavedSuccessMsg('Settings saved locally on this device.');
    onDataChanged();
    setTimeout(() => setSavedSuccessMsg(''), 3000);
  };

  const handleResetSettings = () => {
    resetLocalSettings();
    setWhatsapp('');
    setName('');
    setSavedSuccessMsg('Local device settings have been reset.');
    onDataChanged();
    setTimeout(() => setSavedSuccessMsg(''), 3000);
  };

  const handleClearHistory = () => {
    if (window.confirm('Are you sure you want to clear your local order history?')) {
      clearLocalOrders();
      setSavedSuccessMsg('Order history cleared from this device.');
      onDataChanged();
      setTimeout(() => setSavedSuccessMsg(''), 3000);
    }
  };

  return (
    <div className="w-full flex-1 max-w-xl mx-auto px-4 py-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>← Back</span>
      </button>

      {/* Screen Header */}
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Settings
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Manage your saved preferences for quicker order form autofill
        </p>
      </div>

      {/* Local Storage Privacy Note */}
      <div className="bg-purple-950/40 border border-purple-900/50 rounded-2xl p-4 mb-6 text-xs text-purple-200 flex items-start gap-3">
        <Shield className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          Your settings and order history are stored only on this device/browser.
        </p>
      </div>

      {savedSuccessMsg && (
        <div className="mb-5 p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs font-semibold">
          {savedSuccessMsg}
        </div>
      )}

      {/* Settings Form */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5 flex items-center gap-1.5">
              <Smartphone className="w-3.5 h-3.5 text-purple-400" />
              <span>Default WhatsApp Number</span>
            </label>
            <input
              type="tel"
              placeholder="e.g. 9296965248 or +91 92969 65248"
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-purple-500 transition-colors"
            />
            <p className="text-[11px] text-zinc-500 mt-1">
              Automatically pre-fills your WhatsApp number when opening an order checkout.
            </p>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-300 mb-1.5 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-purple-400" />
              <span>Full Name (Optional)</span>
            </label>
            <input
              type="text"
              placeholder="Your Full Name (Optional)"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-purple-500 transition-colors"
            />
          </div>

          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-sm transition-colors cursor-pointer shadow-lg shadow-purple-950/40"
          >
            <Save className="w-4 h-4" />
            <span>Save Local Settings</span>
          </button>
        </form>

        {/* Danger Zone / Reset */}
        <div className="mt-8 pt-6 border-t border-zinc-800 space-y-3">
          <h2 className="text-xs font-bold text-zinc-400 uppercase tracking-wider">
            Device Data Controls
          </h2>

          <button
            type="button"
            onClick={handleClearHistory}
            className="w-full flex items-center justify-between p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-red-800/50 hover:bg-red-950/20 text-xs text-red-400 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Trash2 className="w-4 h-4" />
              <span>Clear Local Order History</span>
            </span>
          </button>

          <button
            type="button"
            onClick={handleResetSettings}
            className="w-full flex items-center justify-between p-3.5 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-zinc-800 text-xs text-zinc-300 transition-colors cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <RotateCcw className="w-4 h-4" />
              <span>Reset Local Settings</span>
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
