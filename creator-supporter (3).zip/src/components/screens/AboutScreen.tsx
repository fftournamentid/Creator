import React from 'react';
import { siteConfig } from '../../config';
import {
  ArrowLeft,
  MessageSquare,
  ShieldCheck,
  Zap,
  Lock,
  History,
  Tag,
  Headphones,
  CheckCircle,
} from 'lucide-react';

interface AboutScreenProps {
  onBack: () => void;
}

const pillars = [
  {
    title: 'Simple Ordering Process',
    desc: 'Select your package, fill your public link, and complete your order via WhatsApp in seconds without registration barriers.',
    icon: Zap,
  },
  {
    title: 'Direct WhatsApp Communication',
    desc: `Get in touch directly with our support team at ${siteConfig.whatsapp.display}. Real assistance with direct message updates.`,
    icon: MessageSquare,
  },
  {
    title: 'Manual Payment Verification',
    desc: 'Every UPI transaction is reviewed manually before orders are initiated to ensure 100% accuracy and fairness.',
    icon: ShieldCheck,
  },
  {
    title: 'No Passwords Required',
    desc: 'We strictly never ask for your account password, email login, or YouTube/Instagram credentials. Public links only.',
    icon: Lock,
  },
  {
    title: 'Local Order History',
    desc: 'Your submitted orders remain saved on your current device browser via local storage, preserving your history privately.',
    icon: History,
  },
  {
    title: 'Transparent Package Pricing',
    desc: 'Clear upfront INR pricing without hidden processing fees or periodic subscriptions.',
    icon: Tag,
  },
  {
    title: 'Support Through WhatsApp',
    desc: `Have questions regarding delivery pacing or custom requirements? Message us directly anytime via WhatsApp (${siteConfig.whatsapp.display}).`,
    icon: Headphones,
  },
];

export const AboutScreen: React.FC<AboutScreenProps> = ({ onBack }) => {
  return (
    <div className="w-full flex-1 max-w-4xl mx-auto px-4 py-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>← Back</span>
      </button>

      {/* Screen Header */}
      <div className="text-center mb-10">
        <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
          About {siteConfig.name}
        </h1>
        <p className="text-zinc-400 text-xs sm:text-sm mt-2 max-w-lg mx-auto leading-relaxed">
          A practical, simple platform created to help creators discover and launch promotional campaigns without technical friction or complex logins.
        </p>
      </div>

      {/* Summary Box */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 sm:p-8 mb-8 text-zinc-300 text-xs sm:text-sm leading-relaxed space-y-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-purple-400" />
          <span>Our Operating Principles</span>
        </h2>
        <p>
          {siteConfig.name} is structured as a 100% frontend creator utility. We do not store your data on external cloud databases, and we never ask for your account passwords.
        </p>
        <p>
          Every order is verified and processed by our team directly via our official WhatsApp (+91 92969 65248). This direct, personal workflow prevents automated errors and provides clear, human communication for every campaign.
        </p>
      </div>

      {/* Pillars Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {pillars.map((item, idx) => {
          const Icon = item.icon;
          return (
            <div
              key={idx}
              className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-5 hover:border-purple-500/40 transition-colors"
            >
              <div className="w-9 h-9 rounded-xl bg-purple-950/80 border border-purple-800/40 flex items-center justify-center text-purple-300 mb-3">
                <Icon className="w-4 h-4" />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">
                {item.title}
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                {item.desc}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
