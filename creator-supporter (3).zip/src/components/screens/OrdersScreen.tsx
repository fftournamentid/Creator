import React, { useState, useEffect } from 'react';
import { getLocalOrders, clearLocalOrders, OrderRecord } from '../../utils/storage';
import { formatOrderWhatsAppMessage, buildWhatsAppUrl } from '../../utils/links';
import {
  ArrowLeft,
  ShoppingBag,
  Trash2,
  Clock,
  MessageSquare,
  ExternalLink,
  Shield,
} from 'lucide-react';

interface OrdersScreenProps {
  onBack: () => void;
  onOrdersUpdated: () => void;
}

export const OrdersScreen: React.FC<OrdersScreenProps> = ({
  onBack,
  onOrdersUpdated,
}) => {
  const [orders, setOrders] = useState<OrderRecord[]>([]);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  useEffect(() => {
    setOrders(getLocalOrders());
  }, []);

  const handleClearHistory = () => {
    clearLocalOrders();
    setOrders([]);
    setShowClearConfirm(false);
    onOrdersUpdated();
  };

  const handleReopenWhatsApp = (order: OrderRecord) => {
    const text = formatOrderWhatsAppMessage({
      service: order.serviceName,
      packageTitle: order.packageTitle,
      amount: order.amount,
      customerWhatsapp: order.customerWhatsapp,
      customerName: order.customerName,
      channelOrProfileName: order.channelOrProfileName,
      channelOrProfileLink: order.channelOrProfileLink,
      orderId: order.id,
    });
    window.open(buildWhatsAppUrl(text), '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="w-full flex-1 max-w-3xl mx-auto px-4 py-8 animate-in fade-in duration-200">
      {/* Back Button */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>← Back</span>
      </button>

      {/* Screen Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
            My Orders
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Locally stored order history on this device/browser
          </p>
        </div>

        {orders.length > 0 && (
          <div>
            {!showClearConfirm ? (
              <button
                type="button"
                onClick={() => setShowClearConfirm(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-950/40 hover:bg-red-900/40 border border-red-800/50 text-red-300 text-xs font-bold transition-colors cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Order History</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 bg-red-950/70 border border-red-800 p-2 rounded-xl">
                <span className="text-xs text-red-200 font-medium">Are you sure?</span>
                <button
                  type="button"
                  onClick={handleClearHistory}
                  className="px-2.5 py-1 rounded bg-red-600 text-white font-bold text-xs cursor-pointer"
                >
                  Yes, Clear
                </button>
                <button
                  type="button"
                  onClick={() => setShowClearConfirm(false)}
                  className="px-2 py-1 text-xs text-zinc-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Orders List */}
      {orders.length === 0 ? (
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl p-10 text-center">
          <div className="w-14 h-14 rounded-2xl bg-zinc-800/80 flex items-center justify-center text-zinc-500 mx-auto mb-4">
            <ShoppingBag className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-white">No Local Orders Yet</h3>
          <p className="text-xs sm:text-sm text-zinc-400 max-w-sm mx-auto mt-2 leading-relaxed">
            When you configure an order and upload a payment receipt on this website, it is saved locally to your device here.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((ord) => (
            <div
              key={ord.id}
              className="bg-zinc-900 border border-zinc-800 rounded-2xl p-5 shadow-lg space-y-3"
            >
              {/* Top Row: Order ID, Platform, Price, Status */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-black text-purple-300">
                      {ord.id}
                    </span>
                    <span className="text-[10px] bg-zinc-800 text-zinc-300 px-2 py-0.5 rounded-md font-semibold uppercase">
                      {ord.platform}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-white mt-1">
                    {ord.serviceName}
                  </h3>

                  <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400 mt-0.5 font-mono">
                    <span className="bg-purple-950/60 text-purple-300 px-2 py-0.5 rounded border border-purple-800/40">
                      Plan / Quantity: {ord.packageTitle}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-lg sm:text-xl font-black text-white font-mono block">
                    ₹{ord.amount}
                  </span>
                  <span className="inline-block text-[10px] text-amber-300 font-bold bg-amber-950/60 px-2 py-0.5 rounded-full border border-amber-800/40 mt-1">
                    {ord.status}
                  </span>
                </div>
              </div>

              {/* Order Metadata */}
              <div className="border-t border-zinc-800/80 pt-3 text-xs text-zinc-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-zinc-500">
                    <Clock className="w-3.5 h-3.5" />
                    {new Date(ord.createdAt).toLocaleDateString()} at{' '}
                    {new Date(ord.createdAt).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  {ord.screenshotPreview && (
                    <span className="text-emerald-400 text-[11px] font-semibold">
                      Payment Screenshot Attached
                    </span>
                  )}
                </div>

                <p className="truncate text-zinc-300">
                  Target Link: <span className="font-mono text-zinc-400">{ord.channelOrProfileLink}</span>
                </p>
                {ord.customerWhatsapp && (
                  <p className="text-zinc-400">
                    Contact: <span className="font-mono text-zinc-300">{ord.customerWhatsapp}</span>
                  </p>
                )}
              </div>

              {/* Action: Re-open on WhatsApp */}
              <button
                type="button"
                onClick={() => handleReopenWhatsApp(ord)}
                className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-zinc-800 hover:bg-[#25D366] hover:text-black text-xs font-bold text-zinc-200 transition-colors cursor-pointer"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Re-open WhatsApp Message</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Privacy Notice */}
      <div className="mt-8 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-xs text-zinc-500 flex items-center gap-2.5">
        <Shield className="w-4 h-4 text-purple-400 shrink-0" />
        <span>Your order history is stored strictly on this device/browser. No external database is used.</span>
      </div>
    </div>
  );
};
