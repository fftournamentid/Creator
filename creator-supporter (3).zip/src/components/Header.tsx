import React from 'react';
import { siteConfig } from '../config';
import { Menu } from 'lucide-react';

interface HeaderProps {
  onGoHome: () => void;
  onOpenMenu: () => void;
  orderCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onGoHome,
  onOpenMenu,
  orderCount,
}) => {
  return (
    <header className="w-full border-b border-zinc-800/80 bg-[#0b0c10]/95 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
        {/* Brand: Creator Supporter (clicks return to home) */}
        <button
          type="button"
          onClick={onGoHome}
          className="flex items-center gap-2.5 cursor-pointer text-left focus:outline-none"
        >
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-600 flex items-center justify-center shadow-md shadow-purple-900/40 border border-purple-400/20">
            <span className="font-black text-white text-sm">CS</span>
          </div>
          <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white select-none">
            {siteConfig.name}
          </span>
        </button>

        {/* Right Nav: Hamburger menu */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Hamburger Menu Button */}
          <button
            type="button"
            onClick={onOpenMenu}
            className="relative p-2.5 rounded-xl bg-zinc-900 hover:bg-purple-950/60 border border-zinc-800 hover:border-purple-800/50 text-zinc-300 hover:text-white flex items-center justify-center transition-all cursor-pointer shadow-sm"
            title="Menu"
            aria-label="Open Navigation Menu"
          >
            <Menu className="w-5 h-5" />
            {orderCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-purple-600 text-white font-mono text-[9px] font-bold flex items-center justify-center shadow-sm">
                {orderCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
