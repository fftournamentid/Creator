import React from 'react';
import { Youtube, Instagram, Sparkles } from 'lucide-react';
import {
  youtubeServices,
  instagramServices,
  youtubeCategories,
  instagramCategories,
} from '../config';

interface PlatformFilterProps {
  selectedPlatform: 'youtube' | 'instagram';
  onSelectPlatform: (platform: 'youtube' | 'instagram') => void;
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
}

export const PlatformFilter: React.FC<PlatformFilterProps> = ({
  selectedPlatform,
  onSelectPlatform,
  selectedCategory,
  onSelectCategory,
}) => {
  const currentCategories =
    selectedPlatform === 'youtube' ? youtubeCategories : instagramCategories;

  return (
    <div className="w-full flex flex-col items-center justify-center py-2 space-y-2">
      {/* 1. Main Platform Selector [YouTube] [Instagram] */}
      <div className="inline-flex p-1 rounded-xl bg-zinc-900 border border-zinc-800 shadow-md shadow-black/40">
        <button
          type="button"
          onClick={() => {
            onSelectPlatform('youtube');
            onSelectCategory(youtubeCategories[0]);
          }}
          className={`relative flex items-center justify-center gap-2 px-4 sm:px-6 py-1.5 sm:py-2 rounded-lg font-bold text-xs sm:text-sm transition-all duration-200 cursor-pointer ${
            selectedPlatform === 'youtube'
              ? 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-md shadow-red-950/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
          }`}
          aria-pressed={selectedPlatform === 'youtube'}
        >
          <Youtube className={`w-4 h-4 ${selectedPlatform === 'youtube' ? 'text-white' : 'text-red-400'}`} />
          <span>YouTube</span>
          <span
            className={`text-[11px] ml-1 px-1.5 py-0.2 rounded font-mono ${
              selectedPlatform === 'youtube'
                ? 'bg-white/20 text-white'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            {youtubeServices.length}
          </span>
        </button>

        <button
          type="button"
          onClick={() => {
            onSelectPlatform('instagram');
            onSelectCategory(instagramCategories[0]);
          }}
          className={`relative flex items-center justify-center gap-2 px-4 sm:px-6 py-1.5 sm:py-2 rounded-lg font-bold text-xs sm:text-sm transition-all duration-200 cursor-pointer ${
            selectedPlatform === 'instagram'
              ? 'bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 text-white shadow-md shadow-pink-950/60'
              : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/40'
          }`}
          aria-pressed={selectedPlatform === 'instagram'}
        >
          <Instagram className={`w-4 h-4 ${selectedPlatform === 'instagram' ? 'text-white' : 'text-pink-400'}`} />
          <span>Instagram</span>
          <span
            className={`text-[11px] ml-1 px-1.5 py-0.2 rounded font-mono ${
              selectedPlatform === 'instagram'
                ? 'bg-white/20 text-white'
                : 'bg-zinc-800 text-zinc-400'
            }`}
          >
            {instagramServices.length}
          </span>
        </button>
      </div>

      {/* 2. Horizontal Scrollable Service-Tab Selector */}
      <div className="w-full max-w-4xl px-2">
        <div className="flex items-center justify-start sm:justify-center overflow-x-auto pb-1 scrollbar-none gap-1.5">
          {currentCategories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => {
                  onSelectCategory(cat);
                  const targetEl = document.getElementById(
                    `category-${cat.toLowerCase().replace(/\s+/g, '-')}`
                  );
                  if (targetEl) {
                    targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  } else {
                    const fallback = document.getElementById('services-grid');
                    fallback?.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
                className={`shrink-0 flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-xl text-xs sm:text-xs font-black transition-all duration-150 cursor-pointer border select-none ${
                  isActive
                    ? 'bg-gradient-to-r from-purple-600 via-purple-500 to-pink-600 text-white border-purple-400/50 shadow-md shadow-purple-950/60'
                    : 'bg-zinc-900/90 text-zinc-400 hover:text-white border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800/60'
                }`}
                aria-pressed={isActive}
              >
                {isActive && <Sparkles className="w-3 h-3 text-purple-200" />}
                <span>{cat}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
