import React from 'react';
import { siteConfig } from '../config';
import { Mail, MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../utils/links';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  const handleWhatsAppClick = () => {
    const greeting = `Hello ${siteConfig.name}, I need help with creator support.`;
    window.open(buildWhatsAppUrl(greeting), '_blank', 'noopener,noreferrer');
  };

  return (
    <footer className="w-full bg-zinc-950 border-t border-zinc-900 py-10 px-4 text-zinc-400">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="text-center md:text-left">
          <h3 className="font-black text-xl text-white tracking-tight">
            {siteConfig.name}
          </h3>
          <p className="text-xs text-zinc-500 mt-1">
            {siteConfig.tagline}
          </p>
        </div>

        {/* Contact info: Clean display of WhatsApp and Email */}
        <div className="flex flex-col sm:flex-row items-center gap-4 text-xs">
          <div className="flex items-center gap-2 bg-zinc-900 px-3.5 py-2 rounded-xl border border-zinc-800">
            <Mail className="w-3.5 h-3.5 text-purple-400" />
            <span className="text-zinc-500">Email:</span>
            <span className="font-mono text-zinc-200 select-all">
              {siteConfig.email}
            </span>
          </div>

          <button
            type="button"
            onClick={handleWhatsAppClick}
            className="flex items-center gap-2 bg-zinc-900 hover:bg-emerald-950/40 px-3.5 py-2 rounded-xl border border-zinc-800 hover:border-emerald-600/40 transition-colors text-zinc-200 cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-zinc-500">WhatsApp:</span>
            <span className="font-mono text-zinc-200">
              {siteConfig.whatsapp.number.replace(/^91/, '')}
            </span>
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto mt-6 pt-5 border-t border-zinc-900/80 text-center text-[11px] text-zinc-600">
        © {currentYear} {siteConfig.name}. All rights reserved. No database or external tracking.
      </div>
    </footer>
  );
};
