import React from 'react';
import { ServiceItem, siteConfig } from '../config';
import {
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Clock,
  AlertTriangle,
} from 'lucide-react';

interface ServiceCardProps {
  service: ServiceItem;
  onOrder: (service: ServiceItem) => void;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service, onOrder }) => {
  const { notice } = siteConfig;

  return (
    <div
      className={`relative group rounded-2xl p-3 sm:p-3.5 flex flex-col justify-between transition-all duration-200 border bg-zinc-900/90 hover:bg-zinc-900 hover:-translate-y-0.5 shadow-md ${
        service.popular
          ? 'border-purple-500/50 shadow-purple-950/25 ring-1 ring-purple-500/30'
          : 'border-zinc-800/90 hover:border-purple-500/40 hover:shadow-black/50'
      }`}
    >
      <div>
        {/* Top Header Row: Category Badge & Platform Label */}
        <div className="flex items-center justify-between gap-1.5 mb-2">
          <div className="flex items-center gap-1.5 min-w-0">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-950/80 border border-purple-800/50 text-[10px] sm:text-[11px] font-black uppercase tracking-wider text-purple-200 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
              {service.category} Plan
            </span>

            {service.popular && (
              <span className="bg-gradient-to-r from-orange-600 via-pink-600 to-purple-600 text-white text-[8px] sm:text-[9px] font-black px-1.5 py-0.5 rounded-full shadow-sm flex items-center gap-0.5 border border-orange-300/30 tracking-wider shrink-0">
                <Sparkles className="w-2 h-2 text-yellow-300" />
                <span>POPULAR</span>
              </span>
            )}
          </div>

          <span className="text-[10px] font-mono text-zinc-400 bg-zinc-800/80 px-1.5 py-0.5 rounded shrink-0">
            {service.platform === 'youtube' ? 'YouTube' : 'Instagram'}
          </span>
        </div>

        {/* Compact Quantity & Price Row */}
        <div className="bg-zinc-950/90 rounded-xl px-2.5 py-1.5 border border-zinc-800/80 mb-2 flex items-center justify-between">
          <div className="flex items-baseline gap-1 min-w-0">
            <span className="text-xl sm:text-2xl font-black text-white font-mono tracking-tight leading-none">
              {service.quantityDisplay}
            </span>
            <span className="text-[11px] sm:text-xs font-bold text-orange-400 truncate">
              {service.unitLabel}
            </span>
          </div>

          <div className="text-right shrink-0 ml-2">
            <span className="text-lg sm:text-xl font-black text-white font-mono leading-none">
              ₹{service.price}
            </span>
            <span className="text-[9px] text-zinc-500 font-medium ml-0.5">INR</span>
          </div>
        </div>

        {/* Title & Description */}
        <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-purple-200 transition-colors leading-snug line-clamp-1">
          {service.name}
        </h3>

        <p className="text-[10px] sm:text-[11px] text-zinc-400 mt-0.5 leading-relaxed line-clamp-2">
          {service.description}
        </p>

        {/* Compact Features List (2 concise key points) */}
        {service.features && service.features.length > 0 && (
          <div className="mt-1.5 space-y-0.5 border-t border-zinc-800/60 pt-1.5">
            {service.features.slice(0, 2).map((feature, idx) => (
              <div key={idx} className="flex items-center gap-1.5 text-[10px] text-zinc-300 leading-tight">
                <CheckCircle2 className="w-2.5 h-2.5 text-orange-400 shrink-0" />
                <span className="truncate">{feature}</span>
              </div>
            ))}
          </div>
        )}

        {/* Demo Plan Notice (Compact) */}
        {service.category === 'Demo' && (
          <div className="mt-1.5 p-1.5 rounded-lg bg-amber-950/30 border border-amber-800/40 text-amber-200/90 text-[9px] leading-tight flex items-start gap-1">
            <AlertTriangle className="w-2.5 h-2.5 text-amber-400 shrink-0 mt-0.5" />
            <span className="line-clamp-2">{notice}</span>
          </div>
        )}
      </div>

      {/* Bottom Footer Row: Proper Time Notice on Left & Compact Half-Sized Order Button on Right */}
      <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1 text-[10px] sm:text-[11px] text-amber-300 font-medium min-w-0">
          <Clock className="w-3 h-3 text-amber-400 shrink-0" />
          <span className="truncate">10 Minutes to 1 Hour</span>
        </div>

        <button
          type="button"
          onClick={() => onOrder(service)}
          className="order-now-btn shrink-0 flex items-center justify-center gap-1.5 py-1.5 px-3 sm:px-4 rounded-xl font-black text-xs text-white shadow-md cursor-pointer"
        >
          <span>Order Now</span>
          <ArrowRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
};
