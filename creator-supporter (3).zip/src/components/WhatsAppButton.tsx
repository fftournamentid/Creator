import React from 'react';
import { siteConfig } from '../config';
import { buildWhatsAppUrl } from '../utils/links';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  const greeting = `Hello ${siteConfig.name}, I want to inquire about creator support services.`;
  const url = buildWhatsAppUrl(greeting);

  return (
    <div className="fixed bottom-5 right-4 sm:bottom-6 sm:right-6 z-30 group">
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Direct WhatsApp Support"
        className="relative flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-[#25D366] text-white shadow-xl shadow-green-950/50 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer border border-emerald-300/40 no-underline"
      >
        <MessageCircle className="w-6 h-6 sm:w-7 sm:h-7 fill-white text-transparent" />
        <span className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-red-500 rounded-full border-2 border-zinc-950" />
      </a>

      {/* Desktop Tooltip */}
      <div className="absolute right-14 sm:right-16 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center pointer-events-none">
        <span className="bg-zinc-900 text-white text-xs font-semibold py-1.5 px-3 rounded-xl border border-zinc-700 shadow-xl whitespace-nowrap">
          Chat on WhatsApp ({siteConfig.whatsapp.number.replace(/^91/, '')})
        </span>
      </div>
    </div>
  );
};
