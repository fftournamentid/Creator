import React, { useState, useEffect } from 'react';
import { ServiceItem, siteConfig } from '../config';
import { formatOrderWhatsAppMessage, buildWhatsAppUrl, buildUpiDeepLink } from '../utils/links';
import { saveLocalOrder, getLocalSettings, saveLocalSettings, OrderRecord } from '../utils/storage';
import {
  X,
  Send,
  CheckCircle2,
  MessageSquare,
  ArrowLeft,
  ExternalLink,
  AlertCircle,
  Copy,
  Check,
  Smartphone,
} from 'lucide-react';

interface OrderModalProps {
  isOpen: boolean;
  service: ServiceItem | null;
  onClose: () => void;
  onOrderSaved?: (savedOrder: OrderRecord) => void;
  onOpenPaymentScreen?: (amount: number) => void;
}

export const OrderModal: React.FC<OrderModalProps> = ({
  isOpen,
  service,
  onClose,
  onOrderSaved,
  onOpenPaymentScreen,
}) => {
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [channelOrProfileLink, setChannelOrProfileLink] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [channelOrProfileName, setChannelOrProfileName] = useState('');
  const [submittedOrder, setSubmittedOrder] = useState<OrderRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [saveToDefault, setSaveToDefault] = useState(true);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedText, setCopiedText] = useState(false);

  // Load defaults from local settings when modal opens
  useEffect(() => {
    if (isOpen) {
      const settings = getLocalSettings();
      if (settings.savedWhatsapp && !whatsappNumber) {
        setWhatsappNumber(settings.savedWhatsapp);
      }
      if (settings.savedName && !customerName) {
        setCustomerName(settings.savedName);
      }
      setSubmittedOrder(null);
      setErrorMsg('');
      setCopiedText(false);
    }
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen || !service) return null;

  const currentPlatformLabel = service.platform === 'youtube' ? 'YouTube' : 'Instagram';

  const handleCopyUpi = async () => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(siteConfig.payment.upiId);
      } else {
        const textArea = document.createElement('textarea');
        textArea.value = siteConfig.payment.upiId;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
      }
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    } catch {
      setCopiedUpi(true);
      setTimeout(() => setCopiedUpi(false), 2000);
    }
  };

  const handlePayUpiApp = () => {
    const link = buildUpiDeepLink(service.price);
    window.location.href = link;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Required 1: WhatsApp Number
    if (!whatsappNumber.trim()) {
      setErrorMsg('कृपया अपना WhatsApp नंबर दर्ज करें (WhatsApp Number is required)');
      return;
    }

    // Required 2: Channel/Profile Link
    if (!channelOrProfileLink.trim()) {
      setErrorMsg('कृपया अपना Channel या Profile लिंक दर्ज करें (Channel/Profile link is required)');
      return;
    }

    setErrorMsg('');

    if (saveToDefault) {
      saveLocalSettings({
        savedWhatsapp: whatsappNumber.trim(),
        savedName: customerName.trim() || undefined,
      });
    }

    const saved = saveLocalOrder({
      platform: currentPlatformLabel as 'YouTube' | 'Instagram',
      serviceName: service.name,
      packageTitle: `${service.category} · ${service.package}`,
      amount: service.price,
      customerWhatsapp: whatsappNumber.trim(),
      customerName: customerName.trim() || undefined,
      channelOrProfileName: channelOrProfileName.trim() || undefined,
      channelOrProfileLink: channelOrProfileLink.trim(),
      screenshotAttached: false,
      status: 'Order Shared on WhatsApp',
    });

    setSubmittedOrder(saved);
    if (onOrderSaved) {
      onOrderSaved(saved);
    }

    // Directly open WhatsApp on official number 9296965248 with formatted order data
    const messageText = formatOrderWhatsAppMessage({
      service: service.name,
      packageTitle: `${service.category} · ${service.package}`,
      amount: service.price,
      customerWhatsapp: whatsappNumber.trim(),
      customerName: customerName.trim() || undefined,
      channelOrProfileName: channelOrProfileName.trim() || undefined,
      channelOrProfileLink: channelOrProfileLink.trim(),
      orderId: saved.id,
    });

    const targetUrl = buildWhatsAppUrl(messageText);

    try {
      const win = window.open(targetUrl, '_blank', 'noopener,noreferrer');
      if (!win || win.closed || typeof win.closed === 'undefined') {
        // If popup was blocked or in iframe, direct navigation works smoothly
        window.location.href = targetUrl;
      }
    } catch {
      window.location.href = targetUrl;
    }
  };

  const generatedWhatsAppText = submittedOrder
    ? formatOrderWhatsAppMessage({
        service: service.name,
        packageTitle: `${service.category} · ${service.package}`,
        amount: service.price,
        customerWhatsapp: submittedOrder.customerWhatsapp,
        customerName: submittedOrder.customerName,
        channelOrProfileName: submittedOrder.channelOrProfileName,
        channelOrProfileLink: submittedOrder.channelOrProfileLink,
        orderId: submittedOrder.id,
      })
    : '';

  const whatsappUrl = buildWhatsAppUrl(generatedWhatsAppText);

  const handleCopyOrderText = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(generatedWhatsAppText);
      }
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    } catch {
      setCopiedText(true);
      setTimeout(() => setCopiedText(false), 2500);
    }
  };

  const handleOpenWhatsAppAgain = () => {
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="order-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-sm overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl p-5 sm:p-7 my-6 text-white transition-all transform animate-in fade-in zoom-in-95 duration-200 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close checkout"
          className="absolute top-4 right-4 p-2 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {!submittedOrder ? (
          <div>
            {/* Header: Selected Service, Plan, Quantity, Amount */}
            <div className="pr-8 pb-3 border-b border-zinc-800">
              <span className="text-xs font-bold tracking-wider uppercase text-purple-400">
                {currentPlatformLabel} Checkout
              </span>
              <h2
                id="order-modal-title"
                className="text-xl sm:text-2xl font-black text-white mt-0.5 tracking-tight"
              >
                {service.name}
              </h2>

              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="bg-purple-950/80 border border-purple-800/40 text-purple-300 px-2.5 py-0.5 rounded-md text-xs font-bold">
                  Plan: {service.category}
                </span>
                <span className="bg-zinc-800 text-zinc-300 px-2.5 py-0.5 rounded-md font-mono text-xs font-semibold">
                  Quantity: {service.quantityDisplay} {service.unitLabel}
                </span>
                <span className="bg-zinc-800 text-white px-2.5 py-0.5 rounded-md font-mono text-xs font-extrabold">
                  ₹{service.price} INR
                </span>
              </div>
            </div>

            {/* Error Banner */}
            {errorMsg && (
              <div className="mt-4 p-3 rounded-xl bg-red-950/60 border border-red-800/60 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* INLINE PAYMENT INFORMATION FOR CURRENT ORDER */}
            <div className="mt-4 p-4 rounded-2xl bg-zinc-950 border border-purple-900/40 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-zinc-300">UPI Payment for this Order:</span>
                <span className="font-mono text-purple-300 font-extrabold">
                  Amount: ₹{service.price}
                </span>
              </div>

              {/* UPI ID + Copy */}
              <div className="flex items-center justify-between gap-2 bg-zinc-900 p-2.5 rounded-xl border border-zinc-800 text-xs">
                <div>
                  <span className="text-[10px] text-zinc-500 uppercase block font-semibold">
                    UPI ID
                  </span>
                  <span className="font-mono text-white font-bold select-all">
                    {siteConfig.payment.upiId}
                  </span>
                </div>

                <button
                  type="button"
                  onClick={handleCopyUpi}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white font-bold text-[11px] transition-colors cursor-pointer"
                >
                  {copiedUpi ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy UPI ID</span>
                    </>
                  )}
                </button>
              </div>

              {/* Pay with UPI App + QR screen shortcut */}
              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={handlePayUpiApp}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-purple-700 hover:bg-purple-600 text-white font-bold text-xs transition-colors cursor-pointer"
                >
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Pay ₹{service.price} with UPI App</span>
                </button>

                {onOpenPaymentScreen && (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenPaymentScreen(service.price);
                    }}
                    className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold transition-colors cursor-pointer"
                  >
                    <span>View Full QR</span>
                  </button>
                )}
              </div>
            </div>

            {/* ORDER FORM - NO SCREENSHOT HASSEL, DIRECT WHATSAPP SHARE */}
            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              {/* REQUIRED: WhatsApp Number */}
              <div>
                <label className="block text-xs font-bold text-zinc-200 mb-1">
                  WhatsApp Number <span className="text-red-400">*</span>
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. 9296965248 or +91 92969 65248"
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>

              {/* REQUIRED: Channel/Profile Link */}
              <div>
                <label className="block text-xs font-bold text-zinc-200 mb-1">
                  {service.platform === 'youtube'
                    ? 'YouTube Channel / Video Link'
                    : 'Instagram Profile / Reel Link'}{' '}
                  <span className="text-red-400">*</span>
                </label>
                <input
                  type="url"
                  required
                  placeholder={
                    service.platform === 'youtube'
                      ? 'https://youtube.com/@channel or https://youtu.be/...'
                      : 'https://instagram.com/profile or https://instagram.com/reel/...'
                  }
                  value={channelOrProfileLink}
                  onChange={(e) => setChannelOrProfileLink(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-950 border border-zinc-700/80 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>

              {/* OPTIONAL: Full Name */}
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">
                  Full Name <span className="text-zinc-500 text-[11px] font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  placeholder="Your Name (Optional)"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-zinc-950/70 border border-zinc-800 text-white placeholder-zinc-600 text-xs focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>

              {/* OPTIONAL: Channel/Profile Name */}
              <div>
                <label className="block text-xs font-medium text-zinc-400 mb-1">
                  {service.platform === 'youtube' ? 'Channel Name' : 'Profile Name / Handle'}{' '}
                  <span className="text-zinc-500 text-[11px] font-normal">(Optional)</span>
                </label>
                <input
                  type="text"
                  placeholder="Channel or Profile Name (Optional)"
                  value={channelOrProfileName}
                  onChange={(e) => setChannelOrProfileName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-zinc-950/70 border border-zinc-800 text-white placeholder-zinc-600 text-xs focus:outline-none focus:border-purple-500 transition-colors"
                />
              </div>

              {/* Save Default Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="remember-checkout-details"
                  checked={saveToDefault}
                  onChange={(e) => setSaveToDefault(e.target.checked)}
                  className="rounded bg-zinc-900 border-zinc-700 text-purple-600 focus:ring-purple-500 cursor-pointer"
                />
                <label htmlFor="remember-checkout-details" className="text-xs text-zinc-400 cursor-pointer select-none">
                  Remember WhatsApp number on this device for future orders
                </label>
              </div>

              {/* Action Buttons: Direct WhatsApp Share */}
              <div className="pt-2 flex flex-col sm:flex-row items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full sm:w-auto px-4 py-2.5 rounded-xl text-xs font-semibold text-zinc-400 hover:text-white transition-colors cursor-pointer text-center"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="order-now-btn w-full sm:w-auto flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-white text-sm font-bold shadow-lg shadow-orange-950/50 cursor-pointer"
                >
                  <span>Share Order on WhatsApp</span>
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Confirmation Screen: Order Placed & Directly Shared */
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6 text-emerald-400" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">
                  Order Created Successfully
                </span>
                <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-2">
                  <span>Order Shared to WhatsApp</span>
                  <span className="text-xs font-mono font-semibold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
                    {submittedOrder.id}
                  </span>
                </h3>
              </div>
            </div>

            {/* Order Summary Details */}
            <div className="bg-zinc-950 rounded-2xl border border-zinc-800 p-4 space-y-2 text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-zinc-800/80">
                <span className="text-zinc-400">Service:</span>
                <span className="text-white font-bold">{service.name}</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-zinc-800/80">
                <span className="text-zinc-400">Package:</span>
                <span className="text-purple-300 font-semibold">{service.category} · {service.package}</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-zinc-800/80">
                <span className="text-zinc-400">Amount:</span>
                <span className="text-white font-mono font-bold">₹{service.price} INR</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-zinc-800/80">
                <span className="text-zinc-400">Customer WhatsApp:</span>
                <span className="text-white font-mono">{submittedOrder.customerWhatsapp}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">Target Link:</span>
                <span className="text-zinc-300 font-mono truncate max-w-[220px]">{submittedOrder.channelOrProfileLink}</span>
              </div>
            </div>

            {/* Direct WhatsApp Action Button */}
            <div className="space-y-2 pt-1">
              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-green-950/50 transition-all cursor-pointer text-center no-underline"
              >
                <MessageSquare className="w-5 h-5 text-white" />
                <span>Open WhatsApp Chat (+91 92969 65248)</span>
                <ExternalLink className="w-4 h-4 text-emerald-100" />
              </a>
            </div>

            {/* Hindi helper info */}
            <div className="p-3 rounded-xl bg-zinc-950/80 border border-zinc-800 text-xs text-zinc-400 leading-relaxed">
              <p>
                ✓ आपका ऑर्डर डेटा स्वचालित रूप से WhatsApp चैट (+91 92969 65248) के लिए तैयार कर दिया गया है। यदि WhatsApp चैट अपने-आप नहीं खुली है, तो ऊपर दिए गए बटन को दबाएं।
              </p>
            </div>

            {/* Generated WhatsApp Message Preview */}
            <div className="bg-zinc-950 rounded-2xl border border-zinc-800 p-3">
              <div className="flex items-center justify-between text-xs text-zinc-400 mb-2 border-b border-zinc-800 pb-2">
                <span className="flex items-center gap-1.5 font-semibold text-zinc-300 text-[11px]">
                  <MessageSquare className="w-3.5 h-3.5 text-purple-400" />
                  Order WhatsApp Message
                </span>
                <button
                  type="button"
                  onClick={handleCopyOrderText}
                  className="flex items-center gap-1 text-[11px] text-purple-300 hover:text-purple-200 cursor-pointer"
                >
                  {copiedText ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedText ? 'Copied' : 'Copy Text'}</span>
                </button>
              </div>
              <pre className="text-[11px] text-zinc-300 font-mono whitespace-pre-wrap leading-relaxed max-h-32 overflow-y-auto select-all p-1.5 bg-zinc-900/50 rounded-lg">
                {generatedWhatsAppText}
              </pre>
            </div>

            {/* Footer buttons */}
            <div className="flex justify-between items-center pt-1 border-t border-zinc-800/80">
              <button
                type="button"
                onClick={() => setSubmittedOrder(null)}
                className="flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white transition-colors cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Edit Order Details</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-200 hover:text-white transition-colors cursor-pointer"
              >
                Done / Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
