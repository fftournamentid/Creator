import React from 'react';
import { siteConfig } from '../config';
import { buildWhatsAppUrl } from '../utils/links';
import {
  X,
  Home,
  Youtube,
  Instagram,
  HelpCircle,
  QrCode,
  ShoppingBag,
  Settings,
  MessageCircle,
  Info,
  Flame,
  ExternalLink,
} from 'lucide-react';

export type AppScreen =
  | 'home'
  | 'payment'
  | 'how-it-works'
  | 'orders'
  | 'settings'
  | 'about';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeScreen: AppScreen;
  onNavigate: (screen: AppScreen, targetPlatform?: 'youtube' | 'instagram') => void;
  orderCount: number;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activeScreen,
  onNavigate,
  orderCount,
}) => {
  if (!isOpen) return null;

  const handleItemClick = (screen: AppScreen, targetPlatform?: 'youtube' | 'instagram') => {
    onNavigate(screen, targetPlatform);
    onClose();
  };

  const handleWhatsAppContact = () => {
    const greeting = `Hello ${siteConfig.name}, I want to inquire about creator support services.`;
    window.open(buildWhatsAppUrl(greeting), '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Navigation Menu"
      className="fixed inset-0 z-50 flex justify-end bg-black/85 backdrop-blur-sm transition-opacity"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xs sm:max-w-sm bg-zinc-900 border-l border-zinc-800 h-full flex flex-col text-white shadow-2xl animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-purple-700 to-indigo-600 flex items-center justify-center shadow-md shadow-purple-900/40 border border-purple-400/20">
              <Flame className="w-4 h-4 text-white" />
            </div>
            <span className="font-extrabold text-base tracking-tight text-white">
              {siteConfig.name}
            </span>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Items */}
        <div className="flex-1 overflow-y-auto py-3 px-3 space-y-1">
          {/* Home */}
          <button
            type="button"
            onClick={() => handleItemClick('home')}
            className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'home'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <Home className="w-4 h-4 text-purple-400" />
            <span>Home</span>
          </button>

          {/* YouTube */}
          <button
            type="button"
            onClick={() => handleItemClick('home', 'youtube')}
            className="w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800/70 transition-colors cursor-pointer text-left"
          >
            <Youtube className="w-4 h-4 text-red-500" />
            <span>YouTube</span>
          </button>

          {/* Instagram */}
          <button
            type="button"
            onClick={() => handleItemClick('home', 'instagram')}
            className="w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold text-zinc-300 hover:text-white hover:bg-zinc-800/70 transition-colors cursor-pointer text-left"
          >
            <Instagram className="w-4 h-4 text-pink-500" />
            <span>Instagram</span>
          </button>

          {/* How It Works */}
          <button
            type="button"
            onClick={() => handleItemClick('how-it-works')}
            className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'how-it-works'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-purple-400" />
            <span>How It Works</span>
          </button>

          {/* Payment / QR */}
          <button
            type="button"
            onClick={() => handleItemClick('payment')}
            className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'payment'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <QrCode className="w-4 h-4 text-purple-400" />
            <span>Payment / QR</span>
          </button>

          <div className="my-2 border-t border-zinc-800" />

          {/* My Orders */}
          <button
            type="button"
            onClick={() => handleItemClick('orders')}
            className={`w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'orders'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <span className="flex items-center gap-3">
              <ShoppingBag className="w-4 h-4 text-purple-400" />
              <span>My Orders</span>
            </span>
            {orderCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-purple-600 text-white font-mono text-[10px] font-bold flex items-center justify-center">
                {orderCount}
              </span>
            )}
          </button>

          {/* Settings */}
          <button
            type="button"
            onClick={() => handleItemClick('settings')}
            className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'settings'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <Settings className="w-4 h-4 text-purple-400" />
            <span>Settings</span>
          </button>

          {/* Contact WhatsApp */}
          <a
            href={buildWhatsAppUrl(`Hello ${siteConfig.name}, I want to inquire about creator support services.`)}
            target="_blank"
            rel="noopener noreferrer"
            onClick={onClose}
            className="w-full flex items-center justify-between px-3.5 py-3 rounded-xl text-sm font-semibold text-emerald-400 hover:bg-emerald-950/40 transition-colors cursor-pointer text-left no-underline"
          >
            <span className="flex items-center gap-3">
              <MessageCircle className="w-4 h-4" />
              <span>Contact WhatsApp</span>
            </span>
            <ExternalLink className="w-3.5 h-3.5 text-zinc-500" />
          </a>

          {/* About Creator Supporter */}
          <button
            type="button"
            onClick={() => handleItemClick('about')}
            className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-xl text-sm font-semibold transition-colors cursor-pointer text-left ${
              activeScreen === 'about'
                ? 'bg-purple-950/80 text-purple-200 border border-purple-800/50'
                : 'text-zinc-300 hover:text-white hover:bg-zinc-800/70'
            }`}
          >
            <Info className="w-4 h-4 text-purple-400" />
            <span>About {siteConfig.name}</span>
          </button>
        </div>

        {/* Footer info in menu */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-950/80 text-[11px] text-zinc-500 space-y-1">
          <p className="font-semibold text-zinc-400">WhatsApp: {siteConfig.whatsapp.display}</p>
          <p>Local browser storage only · No server</p>
        </div>
      </div>
    </div>
  );
};
