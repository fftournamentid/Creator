import React from 'react';
import { siteConfig } from '../config';
import { Sparkles } from 'lucide-react';

export const AnnouncementBanner: React.FC = () => {
  const { mainText } = siteConfig.announcement;

  return (
    <div className="w-full bg-gradient-to-r from-purple-950 via-purple-900 to-purple-950 border-b border-purple-500/20 text-white py-1.5 px-4 backdrop-blur-md">
      <div className="max-w-6xl mx-auto flex items-center justify-center gap-2 text-center">
        <Sparkles className="w-3.5 h-3.5 text-purple-300 animate-pulse hidden sm:inline" />
        <span className="text-xs sm:text-sm font-extrabold tracking-wider uppercase text-purple-100">
          {mainText}
        </span>
      </div>
    </div>
  );
};
