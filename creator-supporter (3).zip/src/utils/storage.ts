export interface OrderRecord {
  id: string;
  createdAt: string; // ISO date string
  platform: 'YouTube' | 'Instagram';
  serviceName: string;
  packageTitle: string;
  amount: number;
  customerWhatsapp: string;
  customerName?: string;
  channelOrProfileName?: string;
  channelOrProfileLink: string;
  screenshotAttached?: boolean;
  screenshotPreview?: string; // Small thumbnail preview
  status: 'Payment Submitted' | 'Order Shared on WhatsApp';
}

export interface UserSettings {
  savedWhatsapp?: string;
  savedName?: string;
}

const ORDERS_KEY = 'creator_supporter_local_orders';
const SETTINGS_KEY = 'creator_supporter_local_settings';

export function getLocalOrders(): OrderRecord[] {
  try {
    const raw = localStorage.getItem(ORDERS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error('Failed to load local orders', err);
    return [];
  }
}

export function saveLocalOrder(order: Omit<OrderRecord, 'id' | 'createdAt' | 'status'> & { status?: OrderRecord['status'] }): OrderRecord {
  const existing = getLocalOrders();
  const newOrder: OrderRecord = {
    ...order,
    id: `CS-${Math.floor(100000 + Math.random() * 900000)}`,
    createdAt: new Date().toISOString(),
    status: order.status || 'Order Shared on WhatsApp',
  };

  try {
    const updated = [newOrder, ...existing];
    // Keep max 50 orders in local storage to prevent quota exceed
    localStorage.setItem(ORDERS_KEY, JSON.stringify(updated.slice(0, 50)));
  } catch (err) {
    console.warn('Storage quota limit reached, saving without thumbnail', err);
    // If quota exceeded, strip screenshotPreview
    const sanitizedOrder = { ...newOrder, screenshotPreview: undefined };
    const sanitizedExisting = existing.map((o) => ({ ...o, screenshotPreview: undefined }));
    localStorage.setItem(ORDERS_KEY, JSON.stringify([sanitizedOrder, ...sanitizedExisting.slice(0, 30)]));
  }

  return newOrder;
}

export function clearLocalOrders(): void {
  try {
    localStorage.removeItem(ORDERS_KEY);
  } catch (err) {
    console.error('Failed to clear orders', err);
  }
}

export function getLocalSettings(): UserSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

export function saveLocalSettings(settings: UserSettings): void {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}

export function resetLocalSettings(): void {
  try {
    localStorage.removeItem(SETTINGS_KEY);
  } catch (err) {
    console.error('Failed to reset settings', err);
  }
}
