import { siteConfig } from '../config';

/**
 * Creates a WhatsApp URL with an encoded message.
 * Supports web and mobile WhatsApp via wa.me link.
 */
export function buildWhatsAppUrl(message: string, customNumber?: string): string {
  const number = customNumber || siteConfig.whatsapp.number.replace(/\D/g, '');
  const encodedText = encodeURIComponent(message.trim());
  return `https://wa.me/${number}?text=${encodedText}`;
}

export interface OrderWhatsAppPayload {
  service: string;
  packageTitle: string;
  amount: number;
  customerWhatsapp: string;
  customerName?: string;
  channelOrProfileName?: string;
  channelOrProfileLink: string;
  screenshotStatus?: string;
  orderId?: string;
}

/**
 * Generates properly formatted, URL-encoded WhatsApp message for orders.
 */
export function formatOrderWhatsAppMessage(payload: OrderWhatsAppPayload): string {
  const lines: string[] = [
    `Hello ${siteConfig.name},`,
    ``,
    `I want to place an order${payload.orderId ? ` [Order #${payload.orderId}]` : ''}:`,
    ``,
    `📌 Service: ${payload.service}`,
    `📦 Package: ${payload.packageTitle}`,
    `💰 Amount: ₹${payload.amount} INR`,
    ``,
    `📱 WhatsApp Number: ${payload.customerWhatsapp}`,
  ];

  if (payload.customerName && payload.customerName.trim().length > 0) {
    lines.push(`👤 Name: ${payload.customerName.trim()}`);
  }

  if (payload.channelOrProfileName && payload.channelOrProfileName.trim().length > 0) {
    lines.push(`📺 Channel/Profile: ${payload.channelOrProfileName.trim()}`);
  }

  lines.push(`🔗 Target Link: ${payload.channelOrProfileLink}`);

  if (payload.screenshotStatus && payload.screenshotStatus.trim().length > 0) {
    lines.push(`🧾 Payment Status: ${payload.screenshotStatus}`);
  }

  lines.push(``);
  lines.push(`Please confirm and process my order. Thank you!`);

  return lines.join('\n');
}

/**
 * Formats quick payment verification message.
 */
export function formatPaymentVerificationWhatsAppMessage(amount?: number, serviceName?: string): string {
  return [
    `Hello ${siteConfig.name},`,
    ``,
    `I have made the UPI payment${amount ? ` of ₹${amount}` : ''}${serviceName ? ` for ${serviceName}` : ''}.`,
    ``,
    `Please verify and start my promotion campaign.`,
  ].join('\n');
}

/**
 * Generates standard UPI deep link.
 * format: upi://pay?pa=UPI_ID&pn=PAYEE_NAME&am=AMOUNT&cu=INR
 */
export function buildUpiDeepLink(amount?: number): string {
  const { upiId, payeeName } = siteConfig.payment;
  const encodedPayee = encodeURIComponent(payeeName);
  const encodedUpiId = encodeURIComponent(upiId);

  if (amount && amount > 0) {
    return `upi://pay?pa=${encodedUpiId}&pn=${encodedPayee}&am=${amount.toFixed(2)}&cu=INR`;
  }
  return `upi://pay?pa=${encodedUpiId}&pn=${encodedPayee}&cu=INR`;
}
