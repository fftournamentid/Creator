# Creator Supporter

A clean, responsive, dark creator-style frontend website for creator promotion and social media support.

Designed to be 100% frontend-only with **zero database, zero authentication, and zero backend**. All content and pricing are centralized in a single configuration file (`src/config.ts`), with local orders and device settings preserved in the browser's `localStorage`.

---

## Contact Information
- **Website Name:** Creator Supporter
- **WhatsApp Support:** 9269695248 (+91 92696 95248)
- **Email:** hindustan803200@gmail.com
- **Payment UPI ID:** youtubesupporter@axl

---

## Compact Homepage Architecture
The homepage is intentionally kept short, fast, and easy to browse:
1. Top announcement ("THANK YOU FOR WATCHING")
2. Header (Brand, YouTube / Instagram platform filters, Hamburger menu)
3. Main heading & policy notice
4. Platform selector (`[YouTube] [Instagram]`)
5. Horizontal scrollable service-category tabs
6. Service/package cards with delivery notices
7. Clean Footer
8. Floating WhatsApp button

**Large secondary sections (Payment / QR, How It Works, My Orders, Settings, About) are separate full screens accessible exclusively through the Hamburger Menu.**

---

## Dedicated Hamburger Menu Screens
- **Payment / QR Screen:** Dedicated full-screen UPI payment hub with large centered PhonePe QR (`public/phonepe-qr.png`), UPI ID (`youtubesupporter@axl`), Copy UPI button, Pay with UPI App deep link, and "← Back" button.
- **How It Works Screen:** 7-step numbered guide with icons and "← Back" button.
- **My Orders Screen:** Standalone browser-local order manager showing Order ID, platform, package, amount, receipt status, and "← Back" button.
- **Settings Screen:** Standalone device settings view to configure default WhatsApp numbers, reset local settings, and clear order history.
- **About Creator Supporter Screen:** Professional explanation of principles and ordering process with "← Back" button.

---

## Service Categories Structure

### YouTube Categories
1. **Demo:** 111 subscribers — ₹39
2. **Creator Pro:** 500 subscribers — ₹199 | 1K subscribers — ₹299
3. **Half Monetize:** 500 subscribers + 3,000 watch hours — ₹699
4. **VIP:** 1,000 subscribers + 4,000 watch hours — ₹999
5. **Signature:** 10,000 subscribers — ₹1499

### Instagram Categories
1. **Followers:** 120 (₹45), 500 (₹199), 1K (₹349), 15K (₹2499)
2. **Likes:** 500 (₹45), 2K (₹199), 5K (₹349), 25K (₹2499)
3. **Reels:** 5K (₹149), 15K (₹299), 50K (₹699)
4. **Post Views:** 3K (₹129), 10K (₹249)

---

## 1. How to Run the Project

1. Clone or download the repository.
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the local development server:
   ```bash
   npm run dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser.
5. To build for production:
   ```bash
   npm run build
   ```

---

## 2. How to Change Prices & Quantities

Open `src/config.ts`. Locate `youtubeServices` or `instagramServices`. Each item has `category`, `price`, `quantityDisplay`, and `unitLabel`:

```typescript
{
  id: 'yt-demo-111',
  category: 'Demo',
  name: 'Demo Starter Plan',
  platform: 'youtube',
  quantityDisplay: '111',       // Prominent number displayed on card
  unitLabel: 'Subscribers',
  description: 'Entry-level sample package...',
  package: '111 Channel Subscribers',
  price: 39,                     // Change price in ₹ (INR) here
  features: [ ... ],
}
```

Save the file and changes reflect immediately.

---

## 3. How to Change WhatsApp Number or Contact Info

Open `src/config.ts` and update `siteConfig.whatsapp`:

```typescript
whatsapp: {
  display: '+91 92696 95248',
  number: '919269695248', // 10 digits with country code, no + or spaces
},
```

---

## 4. How to Change UPI ID

Open `src/config.ts` and update `siteConfig.payment`:

```typescript
payment: {
  upiId: 'youtubesupporter@axl',
  payeeName: 'Creator Supporter',
  qrImagePath: '/phonepe-qr.png',
  ...
},
```
